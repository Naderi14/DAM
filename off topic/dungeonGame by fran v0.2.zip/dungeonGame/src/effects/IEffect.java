package effects;

import controllers.Dungeon;

public interface IEffect
{
    public void aplicarEfecto(Dungeon dungeon);
}
