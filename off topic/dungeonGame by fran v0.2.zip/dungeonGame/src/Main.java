import controllers.Dungeon;

public class Main {
    public static void main(String[] args)
    {
        Dungeon dungeon = new Dungeon();

        dungeon.mainDungeon();
    }
}