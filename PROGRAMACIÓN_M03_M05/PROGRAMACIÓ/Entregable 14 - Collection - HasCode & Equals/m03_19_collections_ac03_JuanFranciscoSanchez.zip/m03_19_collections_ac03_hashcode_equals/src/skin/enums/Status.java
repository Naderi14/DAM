package skin.enums;

public enum Status {
    RESTING,
    EATING,
    BATTLING
}
