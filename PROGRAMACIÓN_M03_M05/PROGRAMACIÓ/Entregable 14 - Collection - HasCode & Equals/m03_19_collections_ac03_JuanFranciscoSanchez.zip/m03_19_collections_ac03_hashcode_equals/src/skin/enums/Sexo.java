package skin.enums;

public enum Sexo {
    MAN,
    WOMAN,
    NOTDEFINED
}
