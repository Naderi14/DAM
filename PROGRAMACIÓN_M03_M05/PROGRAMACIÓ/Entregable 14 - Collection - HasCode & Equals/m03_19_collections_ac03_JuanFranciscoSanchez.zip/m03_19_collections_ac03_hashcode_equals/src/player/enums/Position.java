package player.enums;

public enum Position {
    DEFENDER, MIDFIELDER, GOALKEEPER, FORWARD
}
