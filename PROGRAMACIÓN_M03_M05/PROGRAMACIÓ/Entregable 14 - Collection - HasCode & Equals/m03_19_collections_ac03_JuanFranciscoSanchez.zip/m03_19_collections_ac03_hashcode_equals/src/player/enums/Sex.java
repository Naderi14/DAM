package player.enums;

public enum Sex {
    WOMAN, MAN, NOTDEFINED
}
