package figure;

// * ©Copyright 2025 Juan Francisco Sanchez <ditarex95@alumnes.ilerna.com>


public interface IsCircle {
    boolean isCircle();
}
