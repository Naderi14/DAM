/*
 * Color.java 1 abr 2025
 *
 *
 * ©Copyright 2025 Juan Francisco Sanchez <ditarex95@alumnes.ilerna.com>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;
public enum Color {
    CYAN,
    MAGENTA,
    YELLOW,
    BLACK
}
