package programacionModularAct1;

/*
 * Juan Francisco Sanchez Castelblanque DAM 1r
 */

public class Main {
    public static void main(String[] args)
    {
        Ejercicio1.sumarDigitosDeNumero();
        Ejercicio2.numeroFactorial();
        Ejercicio3.expCubo();
        Ejercicio4.menorDeDos();
        Ejercicio5.positiveNegativeZero();
        Ejercicio6.porAhoraNoHayNadaAqui();
        Ejercicio7.digitCounter();
        Ejercicio8.cambioDeDivisa();
        Ejercicio9.numeroPrimoOno();
        Ejercicio10.convertidorBinario();
        Ejercicio11.chekPalabraPalindroma();
        Ejercicio12.areaDeTresFiguras();
    }
}
