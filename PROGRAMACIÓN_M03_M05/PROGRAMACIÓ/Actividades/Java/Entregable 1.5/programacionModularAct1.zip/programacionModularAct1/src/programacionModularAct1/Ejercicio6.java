package programacionModularAct1;

/*Realizar una función en Java que reciba un número y devuelva la suma
de sus dígitos.*/

/*
 * Juan Francisco Sanchez Castelblanque DAM 1r
 */

import java.util.Scanner;

public class Ejercicio6 {
    public static void porAhoraNoHayNadaAqui()
    {
        Scanner leer = new Scanner(System.in);

    }
}
