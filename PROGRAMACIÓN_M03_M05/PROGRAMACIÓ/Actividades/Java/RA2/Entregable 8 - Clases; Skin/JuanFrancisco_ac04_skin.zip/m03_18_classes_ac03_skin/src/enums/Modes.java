package enums;

public enum Modes {
    SAVE_THE_WORLD,
    BATTLE_ROYALE,
    CREATIVE
}
