package enums;

public enum Status {
    RESTING,
    EATING,
    BATTLING
}
