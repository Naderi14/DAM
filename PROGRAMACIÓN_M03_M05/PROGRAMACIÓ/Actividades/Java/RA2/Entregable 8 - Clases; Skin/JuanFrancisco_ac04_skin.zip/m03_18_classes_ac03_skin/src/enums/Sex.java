package enums;

public enum Sex {
    MAN,
    WOMAN,
    NOTDEFINED
}
