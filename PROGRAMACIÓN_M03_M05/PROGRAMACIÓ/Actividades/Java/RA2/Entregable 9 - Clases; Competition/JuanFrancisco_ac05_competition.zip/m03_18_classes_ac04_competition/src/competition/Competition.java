package competition;

public class Competition {
    private Car[] cars;
    private Race[] races;
    private int numRaces;
}
