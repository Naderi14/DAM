package enums;

public enum Sex {
    WOMAN, MAN, NOTDEFINED
}
