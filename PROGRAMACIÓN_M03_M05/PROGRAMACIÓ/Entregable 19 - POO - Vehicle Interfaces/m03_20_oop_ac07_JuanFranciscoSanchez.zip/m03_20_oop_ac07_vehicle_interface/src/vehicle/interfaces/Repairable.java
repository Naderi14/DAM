package vehicle.interfaces;

public interface Repairable {
    int CAR = 500;
    int MOTO = 300;
    int TRUCK = 400;
    int BIKE = 50;

    boolean repair();
}
