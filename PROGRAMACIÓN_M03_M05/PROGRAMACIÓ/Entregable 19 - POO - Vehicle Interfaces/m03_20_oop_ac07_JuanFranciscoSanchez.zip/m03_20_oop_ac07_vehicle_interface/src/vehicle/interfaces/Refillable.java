package vehicle.interfaces;

public interface Refillable {
    int CAR = 100;
    int MOTO = 50;
    int TRUCK = 200;

    boolean refill();
}
