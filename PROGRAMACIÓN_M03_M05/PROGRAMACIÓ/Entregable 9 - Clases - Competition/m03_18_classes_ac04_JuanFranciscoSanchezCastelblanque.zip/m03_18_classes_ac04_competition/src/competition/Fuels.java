package competition;

public enum Fuels {
    DIESEL, PETROL, ELECTRIC, HYBRID
}
