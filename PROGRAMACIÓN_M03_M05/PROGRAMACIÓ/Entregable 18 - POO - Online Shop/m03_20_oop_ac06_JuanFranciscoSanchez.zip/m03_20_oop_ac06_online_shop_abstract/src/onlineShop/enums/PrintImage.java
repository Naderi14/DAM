package onlineShop.enums;

public enum PrintImage {
    TIGER, BULL, EAGLE, REINDEER, COBRA
}
