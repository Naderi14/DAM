package onlineShop.enums;

public enum Visor {
    FLAT, CURVED
}
