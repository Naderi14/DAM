package onlineShop.enums;

public enum Color {
    RED, WHITE, BLACK, YELLOW, LYCRA
}
