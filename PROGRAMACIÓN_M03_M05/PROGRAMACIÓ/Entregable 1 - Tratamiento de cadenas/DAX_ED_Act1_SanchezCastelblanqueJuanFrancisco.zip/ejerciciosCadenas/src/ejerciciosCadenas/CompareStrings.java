package ejerciciosCadenas;

/*8. Compara si el String “JAVA” es igual que el String “JavaScript” y muestra el resultado.*/

public class CompareStrings {
    public static void main(String[] args)
    {
        String palabra1 = "JAVA", palabra2 = "JavaScript";

        System.out.println("El resultado es: " + palabra1.compareTo(palabra2));
    }
}
