package ejerciciosCadenas;

public class LongitudTexto {
    public static void main(String[] args)
    {
        String texto = "This is JAVA!";

        System.out.println("La longitud del texto \"This is JAVA!\" es de " + texto.length() + " letras.");
    }
}
