create
    definer = root@`%` procedure images_remove_one(IN p_id_image int, IN p_id_stay int)
BEGIN
	DELETE FROM images WHERE id_image = p_id_image AND id_stay = p_id_stay;
END;

