create
    definer = root@`%` procedure stays_insert_new(IN p_id_category int, IN p_titlename varchar(100),
                                                  IN p_city varchar(50), IN p_location_address varchar(100),
                                                  IN p_description varchar(255), IN p_price decimal(6, 2),
                                                  IN p_num_guests int, IN p_num_baths int, IN p_num_beds int,
                                                  IN p_num_bedrooms int, IN p_active int)
BEGIN
    INSERT INTO stays (
        id_category,
        titlename,
        city,
        location_address,
        description,
        price,
        num_guests,
        num_baths,
        num_beds,
        num_bedrooms,
        active
    )
    VALUES (
        p_id_categorie,
        p_titlename,
        p_city,
        p_location_address,
        p_description,
        p_price,
        p_num_guests,
        p_num_baths,
        p_num_beds,
        p_num_bedrooms,
        p_active
    );
END;

