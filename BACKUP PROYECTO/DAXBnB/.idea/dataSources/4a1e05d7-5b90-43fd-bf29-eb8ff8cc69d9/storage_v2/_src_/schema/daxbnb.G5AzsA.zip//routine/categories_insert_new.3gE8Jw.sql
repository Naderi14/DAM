create
    definer = root@`%` procedure categories_insert_new(IN p_category_name varchar(20))
BEGIN
	INSERT INTO categories (category_name) VALUES (p_category_name);
END;

