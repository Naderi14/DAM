create
    definer = root@`%` procedure stays_update_by_id(IN p_id_stay int, IN p_id_category int, IN p_titlename varchar(100),
                                                    IN p_city varchar(50), IN p_location_address varchar(100),
                                                    IN p_description varchar(255), IN p_price decimal(6, 2),
                                                    IN p_active tinyint(1), IN p_num_guests int, IN p_num_baths int,
                                                    IN p_num_beds int, IN p_num_bedrooms int)
BEGIN
    UPDATE stays SET 
    	id_category = p_id_category,
        titlename = p_titlename,
        city = p_city,
        location_address = p_location_address,
        description = p_description,
        price = p_price,
        active = p_active,
        num_guests = p_num_guests,
        num_baths = p_num_baths,
        num_beds = p_num_beds,
        num_bedrooms = p_num_bedrooms
    WHERE id_stay = p_id_stay;
END;

