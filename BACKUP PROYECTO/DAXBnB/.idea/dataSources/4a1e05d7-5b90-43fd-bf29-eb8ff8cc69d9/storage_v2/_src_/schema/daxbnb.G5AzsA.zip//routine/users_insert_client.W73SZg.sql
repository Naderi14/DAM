create
    definer = root@`%` procedure users_insert_client(IN p_dni varchar(20), IN p_name varchar(100),
                                                     IN p_surname varchar(100), IN p_email varchar(100),
                                                     IN p_phone varchar(20), IN p_username varchar(50),
                                                     IN p_password varchar(255), IN p_address varchar(255),
                                                     IN p_birth_date date)
BEGIN
    DECLARE last_id INT;

    INSERT INTO users (dni, name, surname, email, phone, username, password)
    VALUES (p_dni, p_name, p_surname, p_email, p_phone, p_username, p_password);

    SET last_id = LAST_INSERT_ID();

    INSERT INTO clients (id_user, address, birth_date)
    VALUES (last_id, p_address, p_birth_date);
END;

