create
    definer = root@`%` procedure categories_delete_by_id(IN p_id_category int)
BEGIN
	DELETE FROM categories WHERE id_category = p_id_category;
END;

