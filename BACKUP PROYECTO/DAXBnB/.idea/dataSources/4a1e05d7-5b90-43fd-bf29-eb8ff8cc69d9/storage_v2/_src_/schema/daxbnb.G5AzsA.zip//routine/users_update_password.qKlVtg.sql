create
    definer = root@`%` procedure users_update_password(IN p_dni varchar(9), IN p_new_password varchar(255))
BEGIN
    UPDATE users SET password = p_new_password WHERE dni = p_dni;
END;

