create
    definer = root@`%` procedure features_delete_by_id(IN p_id_feature int)
BEGIN
	DELETE FROM features WHERE id_feature = p_id_feature;
END;

