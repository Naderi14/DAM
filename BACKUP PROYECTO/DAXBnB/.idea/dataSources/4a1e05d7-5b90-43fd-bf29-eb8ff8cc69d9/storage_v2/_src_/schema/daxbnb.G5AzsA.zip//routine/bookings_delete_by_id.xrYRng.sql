create
    definer = root@`%` procedure bookings_delete_by_id(IN p_id_booking int)
BEGIN
	DELETE FROM bookings WHERE id_booking = p_id_booking;
END;

