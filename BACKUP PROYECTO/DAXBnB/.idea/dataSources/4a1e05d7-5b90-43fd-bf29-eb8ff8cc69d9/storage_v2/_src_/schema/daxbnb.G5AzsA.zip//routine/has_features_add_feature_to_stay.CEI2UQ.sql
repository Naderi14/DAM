create
    definer = root@`%` procedure has_features_add_feature_to_stay(IN p_id_stay int, IN p_id_feature int)
BEGIN
	INSERT INTO stay_feature (id_stay, id_feature) VALUES (p_id_stay, p_id_feature);
END;

