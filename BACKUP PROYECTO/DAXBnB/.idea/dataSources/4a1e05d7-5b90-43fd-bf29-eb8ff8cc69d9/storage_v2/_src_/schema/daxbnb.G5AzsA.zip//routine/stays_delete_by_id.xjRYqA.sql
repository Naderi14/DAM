create
    definer = root@`%` procedure stays_delete_by_id(IN p_id_stay int)
BEGIN
	DELETE FROM stays WHERE id_stay = p_id_stay;
END;

