create
    definer = root@`%` procedure features_insert_new(IN p_feature_info varchar(255))
BEGIN
	INSERT INTO features (feature_info) VALUES (p_feature_info);
END;

