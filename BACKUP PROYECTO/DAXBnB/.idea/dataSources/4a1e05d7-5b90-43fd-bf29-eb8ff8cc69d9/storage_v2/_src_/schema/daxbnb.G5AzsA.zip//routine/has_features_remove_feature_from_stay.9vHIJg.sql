create
    definer = root@`%` procedure has_features_remove_feature_from_stay(IN p_id_stay int, IN p_id_feature int)
BEGIN
	DELETE FROM stay_feature WHERE id_stay = p_id_stay AND id_feature = p_id_feature;
END;

