create
    definer = root@`%` procedure users_delete_by_dni(IN p_dni varchar(9))
BEGIN
    DECLARE v_id_user INT;

    SELECT id_user INTO v_id_user
    FROM users
    WHERE dni = p_dni;

    IF v_id_user IS NOT NULL THEN
	    DELETE FROM clients WHERE id_user = v_id_user;
	    DELETE FROM admins WHERE id_user = v_id_user;
	    DELETE FROM users WHERE id_user = v_id_user;
	END IF;
END;

