create
    definer = root@`%` procedure users_insert_admin(IN p_dni varchar(9), IN p_name varchar(50),
                                                    IN p_surname varchar(50), IN p_email varchar(50),
                                                    IN p_phone varchar(10), IN p_username varchar(50),
                                                    IN p_password varchar(255), IN p_perm_level int)
BEGIN
	DECLARE last_id INT;

    INSERT INTO users (dni, name, surname, email, phone, username, password)
    VALUES (p_dni, p_name, p_surname, p_email, p_phone, p_username, p_password);

    SET last_id = LAST_INSERT_ID();

    INSERT INTO admins (id_user, perm_level)
    VALUES (p_id_user, p_perm_level);
END;

