create
    definer = root@`%` procedure bookings_insert_new(IN p_init_date date, IN p_end_date date, IN p_id_user int,
                                                     IN p_id_stay int)
BEGIN
	INSERT INTO bookings (init_date, end_date, id_user, id_stay) VALUES (p_init_date, p_end_date, p_id_user, p_id_stay);
END;

