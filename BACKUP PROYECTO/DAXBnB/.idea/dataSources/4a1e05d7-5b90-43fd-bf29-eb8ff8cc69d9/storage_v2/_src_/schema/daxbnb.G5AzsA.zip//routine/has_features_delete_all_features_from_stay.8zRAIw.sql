create
    definer = root@`%` procedure has_features_delete_all_features_from_stay(IN p_id_stay int)
BEGIN
	DELETE FROM stay_feature WHERE id_stay = p_id_stay;
END;

