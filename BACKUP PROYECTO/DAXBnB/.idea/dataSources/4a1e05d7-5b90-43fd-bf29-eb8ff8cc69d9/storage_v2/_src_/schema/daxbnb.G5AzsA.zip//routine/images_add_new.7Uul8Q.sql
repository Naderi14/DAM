create
    definer = root@`%` procedure images_add_new(IN p_path_url varchar(255), IN p_description varchar(255),
                                                IN p_id_stay int)
BEGIN
    INSERT INTO images (path_url, description, id_stay)
    VALUES (p_path_url, p_description, p_id_stay);
END;

